SaaS Portal - autodelete expired databases
==========================================

The module adds cron job to delete expired trial databases.
