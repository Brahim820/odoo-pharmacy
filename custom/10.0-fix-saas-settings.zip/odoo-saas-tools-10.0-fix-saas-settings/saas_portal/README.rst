SaaS Portal
===========

Module for main database in saas structure.

Notes
-----

* be sure that you allow pop-ups in your browser. It would necessary when you click button to Create, Edit, Upgrade, Delete databases.
