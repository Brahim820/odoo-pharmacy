==========================
 Mailgun for saas clients
==========================

This module automatically creates mail domain on your account
of http://www.mailgun.com/ service for client's databases on selected plan.
Every domain on mailgun.com should be validated before use.
Mailgun.com require special DNS records on your DNS server for validation and mail routing.
The records also created automatically by the module.
Amazon Web Services Route 53 account are required for this purpose.


Contributors
============
* Ildar Nasyrov <Nasyrov@it-projects.info>

Sponsors
========
* `IT-Projects LLC <https://it-projects.info>`__

Further information
===================

Usage instructions: `<doc/index.rst>`__

Changelog: `<doc/changelog.rst>`__

Tested on Odoo 9.0 1b5c2ced45b508a6e86681cad47efe12c486362b
