# -*- coding: utf-8 -*-
{
    'name': 'auth_oauth - check client_id',
    'version': '1.0.0',
    'author': 'Ivan Yelizariev',
    'license': 'LGPL-3',
    'category': 'SaaS',
    'website': 'https://it-projects.info',

    'depends': ['auth_oauth'],
    'data': [],
    'installable': True,

    'description': '''
    ''',
}
