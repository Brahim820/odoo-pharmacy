=============================
 Local IP for OAuth requests
=============================

Usage
=====

* `Enable Technical Features <https://odoo-development.readthedocs.io/en/latest/odoo/usage/technical-features.html>`__
* open ``Settings / Users / OAuth Providers``
* select a Provider you need
* click ``[Edit]``
* set **Local IP** and **Local Port**
* click ``[Save]``

This local address will be used whenever you authenticate via the Provider.
