===================
 SaaS Sysadmin AWS
===================

Usage
=====

* Get your Access Key ID and Secret Access Key http://docs.aws.amazon.com/AWSSimpleQueueService/latest/SQSGettingStartedGuide/AWSCredentials.html
* Open menu ``Settings / SaaS Portal Settings``, put your credendials in ``AWS access`` section and click ``[apply]``
