# -*- coding: utf-8 -*-
{
    'name': "Saas Sysadmin AWS",
    'author': "IT-Projects LLC, Ildar Nasyrov",
    'license': 'LGPL-3',
    'website': "https://twitter.com/nasyrov_ildar",
    'category': 'SaaS',
    'version': '1.0.0',
    'depends': ['saas_portal'],
    'data': [
        'views/res_config.xml',
    ],
}
