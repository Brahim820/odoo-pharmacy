SaaS Portal - templates
=======================

Module adds web page with a database templates for choosing.

Use this path:

    /saas_portal_templates/select-template

It's something like that https://accounts.odoo.com/odoo-enterprise/select-app but it is based on template databases, rather than apps
