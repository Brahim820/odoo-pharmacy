SaaS Portal Demo
================

This module creates page with SaaS Plan description.

URL description page: '/demo/<odoo_version>/<plan_url>' (e.g. /demo/8.0/best_plan)

Parameters <odoo_version> and <plan_url> are specified in SaaS/SaaS/Plans/Website Settings


In description page 'Live Preview' button creates a demo database with plan modules.
