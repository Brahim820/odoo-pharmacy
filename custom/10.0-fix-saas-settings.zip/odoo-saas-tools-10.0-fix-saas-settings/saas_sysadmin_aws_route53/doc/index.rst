
===========================
 SaaS Sysadmin AWS Route53
===========================

Usage
=====

* Open menu ``SaaS / SaaS / Servers``, open your server's form
* Click ``[edit]`` and define Server IP Address then click ``[save]``
* Now as Server IP Address field is defined you may edit AWS Hosted Zone field
* Click ``[edit]`` and start typing in AWS Hosted Zone field
* From AWS Hosted Zone field's drop-down menu choose ``[Create and Edit...]``
* Check ``Create Zone`` flag if you want to create zone. Leave it unchecked if you already have the zone.
* Click ``[save]`` on AWS Hosted Zone form and ``[save]`` on server's form
